Here's your Figma AI prompt — copy and paste it directly:

---

**FIGMA AI PROMPT:**

Add a new tab to the existing mobile navigation bar called **"Home"** — this becomes the primary tab of the app. The tab icon should be a shield or home icon, placed as the first tab in the bottom navigation. The existing tabs (History, Map, Profile) shift accordingly.

**HOME TAB — SCREEN LAYOUT**

The Home screen should match the visual design language already established in this file — same typography, same spacing system, same card styles, same green (#133D13) and red (#DC2626) color tokens.

The screen is structured as a scrollable mobile view with the following sections from top to bottom:

**1. Top status bar**
A full-width colored banner just below the device status bar. It has three states:
- **Online (green #133D13):** Shows a shield icon + text "Protected · GPS Active"
- **Cell only (amber #D97706):** Shows a signal icon + "Limited · SMS Mode" + a small banner below it that says "Dial *346*911# if needed"
- **Offline (red #DC2626):** Shows a wifi-off icon + "Offline · Siren Mode Active" + a spinning retry indicator with text like "Retrying · Attempt 3"

**2. Emergency type selector**
A horizontal row of four pill/chip buttons below the status bar:
- General (red)
- Medical (blue #2563EB)
- Fire (orange #EA580C)
- Security (green #133D13)
One pill is always selected/active — show "General" as default active state with a filled background. Inactive pills have a light bordered style.

**3. SOS Button — center hero element**
A large circular button, centered horizontally, with:
- Red (#DC2626) filled background
- White shield icon above the label
- Bold "SOS" text
- Subtle text below: "Hold to send alert"
- Two or three soft pulse/ripple rings radiating outward from the circle in idle state (animated in prototype, shown as concentric faded circles in design)
- A countdown ring variant: when pressed, a circular progress stroke appears around the outside counting down from 5 to 0. The center text changes to show the countdown number. A "Tap to cancel" label appears below.
- An SVG ring progress indicator wrapping the button (stroke-dasharray style) to communicate the countdown visually

**4. Nearby Responders strip**
Label: "Nearby Responders" in small bold uppercase
A horizontal scrollable row of responder cards. Each card shows:
- Colored avatar circle with initials (e.g. "JO")
- A colored status dot (green = available, amber = busy)
- Responder name (truncated)
- Role badge (Security / Medical / Fire)
- Distance in metres and ETA in minutes

**5. Recent Activity section**
Label: "Recent Activity" on the left, and a **"View all"** text link on the right in green (#133D13)

Below it, show 2–3 alert history cards. Each card contains:
- A colored square icon (matching alert type)
- Alert type label (e.g. "Security Alert") + status badge (Resolved / Cancelled / Pending) inline
- Date + location in smaller muted text below
- If resolved: a small response time line (e.g. "⚡ 72s response · John O.")
- A subtle right-facing chevron

**"VIEW ALL" → SEPARATE HISTORY INTERFACE**

When the user taps **"View all"**, they are taken to a **new separate screen** — NOT a modal, NOT a bottom sheet. This is a full standalone screen that sits outside the tab bar flow entirely.

This History screen should have:
- A back arrow ("←") in the top left that returns the user to the Home tab
- A page title "Alert History" with subtitle "Your safety record"
- Three stat cards in a row: Total Alerts / Resolved count + percentage / Avg response time
- A filter tab row: All · Resolved · Cancelled · Pending (pill tabs, active state filled green)
- A scrollable list of all alert history cards (same card style as on Home)
- Each card is tappable and opens a bottom sheet detail view with: incident ID, location, date, responder name, response time, a vertical timeline of events, and a "View full incident report" CTA button for resolved cases
- An empty state (shield icon + message) if a filter returns no results
- A subtle green insight card at the bottom: "Your safety score: Atlas responded faster than average..."

**LOCALSTORAGE DATA NOTE FOR PROTOTYPE**

This is a prototype that uses browser localStorage to simulate a real backend. The alert history list shown in both the Home tab's Recent Activity section and the full History screen should be driven by a shared localStorage key called `atlas_recent_alerts`. Any alert triggered via the SOS button on the Home tab writes a new entry to this key, which immediately appears at the top of the Recent Activity list and in the full History screen. The History screen polls this key so it always reflects the latest data. When building the Figma prototype interactions, treat this as a live-syncing data source — the history should feel like it updates in real time as the user sends alerts.

Both the Recent Activity preview (Home tab) and the full History screen share the same card component — build it as a reusable Figma component with variants for: type (security / medical / fire / general / false\_alarm), status (resolved / cancelled / pending), and size (compact for home preview, full for history list).

---

That's the full prompt. Paste it into Figma AI and it should scaffold the entire Home tab plus the History flow. Good luck Monday! 🛡️