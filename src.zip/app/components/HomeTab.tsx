import { Shield, ShieldAlert, Signal, WifiOff, Loader2, ChevronRight, AlertTriangle, Flame, Activity, MapPin, Phone, Clock, X, Navigation } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "./ui/dialog";

interface HomeTabProps {
  onNavigateToQuiz?: () => void;
  onViewHistory?: () => void;
}

type ConnectionStatus = "online" | "cell" | "offline";
type EmergencyType = "general" | "medical" | "fire" | "security";
type AlertDialogState = "hidden" | "sending" | "dispatched" | "tracking";

interface Alert {
  id: string;
  type: EmergencyType;
  status: "resolved" | "cancelled" | "pending";
  location: string;
  date: string;
  responseTime?: string;
  responder?: string;
}

export function HomeTab({ onNavigateToQuiz, onViewHistory }: HomeTabProps) {
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>("online");
  const [selectedType, setSelectedType] = useState<EmergencyType>("general");
  const [isCountingDown, setIsCountingDown] = useState(false);
  const [countdown, setCountdown] = useState(5);
  const [retryAttempt, setRetryAttempt] = useState(3);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [alertDialogState, setAlertDialogState] = useState<AlertDialogState>("hidden");
  const [currentAlert, setCurrentAlert] = useState<Alert | null>(null);

  // Load alerts from localStorage on mount
  useEffect(() => {
    const storedAlerts = localStorage.getItem('atlas_recent_alerts');
    if (storedAlerts) {
      setAlerts(JSON.parse(storedAlerts));
    }
  }, []);

  // Countdown logic
  useEffect(() => {
    if (isCountingDown && countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else if (isCountingDown && countdown === 0) {
      handleSOSComplete();
    }
  }, [isCountingDown, countdown]);

  const emergencyTypes = [
    { id: "general" as EmergencyType, label: "General", color: "#DC2626" },
    { id: "medical" as EmergencyType, label: "Medical", color: "#2563EB" },
    { id: "fire" as EmergencyType, label: "Fire", color: "#EA580C" },
    { id: "security" as EmergencyType, label: "Security", color: "#008751" }
  ];

  const nearbyResponders = [
    { 
      initials: "JO", 
      name: "John Okafor", 
      role: "Security",
      distance: "450m",
      eta: "2 min",
      status: "available",
      color: "#008751" 
    },
    { 
      initials: "AD", 
      name: "Aisha Danjuma", 
      role: "Medical",
      distance: "890m",
      eta: "4 min",
      status: "busy",
      color: "#2563EB" 
    },
    { 
      initials: "CE", 
      name: "Chidi Eze", 
      role: "Fire",
      distance: "1.2km",
      eta: "5 min",
      status: "available",
      color: "#EA580C" 
    }
  ];

  const handleSOSPress = () => {
    setIsCountingDown(true);
    setCountdown(5);
  };

  const handleSOSCancel = () => {
    setIsCountingDown(false);
    setCountdown(5);
  };

  const handleSOSComplete = () => {
    const newAlert: Alert = {
      id: Date.now().toString(),
      type: selectedType,
      status: "pending",
      location: "Victoria Island, Lagos",
      date: new Date().toISOString(),
    };

    setCurrentAlert(newAlert);
    const updatedAlerts = [newAlert, ...alerts].slice(0, 10);
    setAlerts(updatedAlerts);
    localStorage.setItem('atlas_recent_alerts', JSON.stringify(updatedAlerts));
    
    setIsCountingDown(false);
    setCountdown(5);

    // Show sending state
    setAlertDialogState("sending");

    // After 2 seconds, show dispatched state
    setTimeout(() => {
      setAlertDialogState("dispatched");
      
      // Update alert to resolved after showing dispatched
      setTimeout(() => {
        const resolvedAlert = {
          ...newAlert,
          status: "resolved" as const,
          responseTime: "72s",
          responder: "John O."
        };
        const finalAlerts = [resolvedAlert, ...alerts].slice(0, 10);
        setAlerts(finalAlerts);
        setCurrentAlert(resolvedAlert);
        localStorage.setItem('atlas_recent_alerts', JSON.stringify(finalAlerts));
      }, 1000);
    }, 2000);
  };

  const getStatusConfig = () => {
    switch (connectionStatus) {
      case "online":
        return {
          bgColor: "#008751",
          icon: <Shield size={18} />,
          text: "Protected · GPS Active"
        };
      case "cell":
        return {
          bgColor: "#D97706",
          icon: <Signal size={18} />,
          text: "Limited · SMS Mode"
        };
      case "offline":
        return {
          bgColor: "#DC2626",
          icon: <WifiOff size={18} />,
          text: "Offline · Siren Mode Active"
        };
    }
  };

  const statusConfig = getStatusConfig();

  const getAlertIcon = (type: EmergencyType) => {
    switch (type) {
      case "security": return <Shield size={20} className="text-[#008751]" />;
      case "medical": return <Activity size={20} className="text-[#2563EB]" />;
      case "fire": return <Flame size={20} className="text-[#EA580C]" />;
      default: return <AlertTriangle size={20} className="text-[#DC2626]" />;
    }
  };

  const getAlertColor = (type: EmergencyType) => {
    switch (type) {
      case "security": return "#008751";
      case "medical": return "#2563EB";
      case "fire": return "#EA580C";
      default: return "#DC2626";
    }
  };

  return (
    <div className="h-full overflow-y-auto pb-20 bg-white">
      {/* Top Status Bar */}
      <div 
        className="w-full px-4 py-3 flex items-center justify-center gap-2 text-white"
        style={{ backgroundColor: statusConfig.bgColor }}
      >
        {statusConfig.icon}
        <span className="font-semibold text-sm">{statusConfig.text}</span>
      </div>

      {/* Cell Only Banner */}
      {connectionStatus === "cell" && (
        <div className="bg-amber-100 border-b border-amber-200 px-4 py-2 text-center">
          <p className="text-sm text-amber-900">Dial *346*911# if needed</p>
        </div>
      )}

      {/* Offline Retry Banner */}
      {connectionStatus === "offline" && (
        <div className="bg-red-100 border-b border-red-200 px-4 py-2 flex items-center justify-center gap-2">
          <Loader2 size={16} className="text-red-700 animate-spin" />
          <p className="text-sm text-red-900">Retrying · Attempt {retryAttempt}</p>
        </div>
      )}

      <div className="px-4 pt-6">
        {/* Emergency Type Selector */}
        <div className="mb-6">
          <h3 className="text-xs uppercase tracking-wide font-semibold text-gray-500 mb-3">EMERGENCY TYPE</h3>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {emergencyTypes.map((type) => (
              <button
                key={type.id}
                onClick={() => setSelectedType(type.id)}
                className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all min-h-[44px] ${
                  selectedType === type.id
                    ? 'text-white'
                    : 'bg-white border-2 text-gray-700'
                }`}
                style={{
                  backgroundColor: selectedType === type.id ? type.color : undefined,
                  borderColor: selectedType === type.id ? type.color : '#E5E7EB'
                }}
              >
                {type.label}
              </button>
            ))}
          </div>
        </div>

        {/* SOS Button */}
        <div className="mb-8 flex flex-col items-center">
          <button
            onClick={isCountingDown ? handleSOSCancel : handleSOSPress}
            className="relative size-48 rounded-full bg-[#DC2626] text-white flex flex-col items-center justify-center shadow-2xl transition-transform active:scale-95"
          >
            {/* Pulse rings - only show when not counting down */}
            {!isCountingDown && (
              <>
                <div className="absolute inset-0 rounded-full bg-[#DC2626] opacity-30 animate-ping"></div>
                <div className="absolute inset-[-12px] rounded-full border-4 border-[#DC2626] opacity-20"></div>
                <div className="absolute inset-[-24px] rounded-full border-4 border-[#DC2626] opacity-10"></div>
              </>
            )}

            {/* Countdown ring */}
            {isCountingDown && (
              <svg className="absolute inset-0 size-full -rotate-90">
                <circle
                  cx="96"
                  cy="96"
                  r="90"
                  stroke="#ffffff"
                  strokeWidth="4"
                  fill="none"
                  strokeDasharray={`${(countdown / 5) * 565.48} 565.48`}
                  className="transition-all duration-1000"
                />
              </svg>
            )}
            
            {isCountingDown ? (
              <span className="font-bold text-6xl z-10">{countdown}</span>
            ) : (
              <>
                <ShieldAlert size={56} className="mb-2 z-10" />
                <span className="font-bold text-3xl z-10">SOS</span>
              </>
            )}
          </button>
          <p className="mt-3 text-sm text-gray-600">
            {isCountingDown ? "Tap to cancel" : "Hold to send alert"}
          </p>
        </div>

        {/* Connection Status Switcher (for testing) */}
        <div className="mb-6 p-3 bg-gray-50 rounded-lg">
          <p className="text-xs text-gray-600 mb-2">Test Connection Status:</p>
          <div className="flex gap-2">
            <button
              onClick={() => setConnectionStatus("online")}
              className={`px-3 py-1 rounded text-xs font-semibold ${
                connectionStatus === "online" ? "bg-[#008751] text-white" : "bg-white border"
              }`}
            >
              Online
            </button>
            <button
              onClick={() => setConnectionStatus("cell")}
              className={`px-3 py-1 rounded text-xs font-semibold ${
                connectionStatus === "cell" ? "bg-[#D97706] text-white" : "bg-white border"
              }`}
            >
              Cell Only
            </button>
            <button
              onClick={() => setConnectionStatus("offline")}
              className={`px-3 py-1 rounded text-xs font-semibold ${
                connectionStatus === "offline" ? "bg-[#DC2626] text-white" : "bg-white border"
              }`}
            >
              Offline
            </button>
          </div>
        </div>

        {/* Nearby Responders */}
        <div className="mb-6">
          <h3 className="text-xs uppercase tracking-wide font-semibold text-gray-500 mb-3">NEARBY RESPONDERS</h3>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {nearbyResponders.map((responder, index) => (
              <Card key={index} className="min-w-[180px] p-3 border border-gray-200">
                <div className="flex items-center gap-2 mb-2">
                  <div 
                    className="size-10 rounded-full flex items-center justify-center text-white font-bold text-sm"
                    style={{ backgroundColor: responder.color }}
                  >
                    {responder.initials}
                  </div>
                  <div 
                    className={`size-2 rounded-full ${
                      responder.status === 'available' ? 'bg-green-500' : 'bg-amber-500'
                    }`}
                  ></div>
                </div>
                <p className="font-semibold text-sm mb-1 truncate">{responder.name}</p>
                <p className="text-xs text-gray-600 mb-2 px-2 py-0.5 bg-gray-100 rounded inline-block">
                  {responder.role}
                </p>
                <div className="flex items-center justify-between text-xs text-gray-500 mt-2">
                  <span>📍 {responder.distance}</span>
                  <span>⏱️ {responder.eta}</span>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Recent Activity Section */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs uppercase tracking-wide font-semibold text-gray-500">RECENT ACTIVITY</h3>
            <button 
              onClick={onViewHistory}
              className="text-sm font-semibold text-[#008751] flex items-center gap-1"
            >
              View all
              <ChevronRight size={16} />
            </button>
          </div>
          
          {alerts.length === 0 ? (
            <Card className="p-8 text-center border border-gray-200">
              <Shield className="mx-auto mb-3 text-gray-300" size={48} />
              <p className="text-sm text-gray-500">No recent alerts</p>
            </Card>
          ) : (
            <div className="space-y-3">
              {alerts.slice(0, 3).map((alert) => (
                <Card 
                  key={alert.id} 
                  className="p-4 border border-gray-200 hover:border-[#008751] transition-colors cursor-pointer"
                >
                  <div className="flex items-start gap-3">
                    <div 
                      className="size-10 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ backgroundColor: `${getAlertColor(alert.type)}15` }}
                    >
                      {getAlertIcon(alert.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <p className="font-semibold text-sm capitalize">{alert.type} Alert</p>
                        <span 
                          className={`px-2 py-0.5 text-xs rounded-full font-medium ${
                            alert.status === 'resolved' 
                              ? 'bg-green-50 text-green-700'
                              : alert.status === 'cancelled'
                              ? 'bg-gray-100 text-gray-700'
                              : 'bg-amber-50 text-amber-700'
                          }`}
                        >
                          {alert.status.charAt(0).toUpperCase() + alert.status.slice(1)}
                        </span>
                      </div>
                      <p className="text-xs text-gray-600 mb-1">
                        {new Date(alert.date).toLocaleString()} · {alert.location}
                      </p>
                      {alert.responseTime && alert.responder && (
                        <p className="text-xs text-gray-500">
                          ⚡ {alert.responseTime} response · {alert.responder}
                        </p>
                      )}
                    </div>
                    <ChevronRight size={18} className="text-gray-400 flex-shrink-0" />
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Emergency Alert Dialog */}
      <Dialog open={alertDialogState !== "hidden"} onOpenChange={() => setAlertDialogState("hidden")}>
        <DialogContent className="max-w-md p-0 gap-0 overflow-hidden">
          {alertDialogState === "sending" && (
            <div className="p-8 text-center">
              <Loader2 className="mx-auto mb-4 text-[#008751] animate-spin" size={48} />
              <h3 className="text-xl font-semibold mb-2">Sending...</h3>
              <p className="text-sm text-gray-600">Alerting nearby responders</p>
            </div>
          )}

          {alertDialogState === "dispatched" && currentAlert && (
            <div>
              {/* Header */}
              <div className="bg-[#008751] text-white p-6 text-center">
                <div className="mb-3">
                  <div className="mx-auto size-16 bg-white/20 rounded-full flex items-center justify-center mb-3">
                    <Shield size={32} />
                  </div>
                  <h2 className="text-2xl font-bold mb-1">Help Dispatched ✓</h2>
                </div>
                <div className="bg-white/10 rounded-lg p-4">
                  <p className="font-semibold mb-1">John O. responding</p>
                  <p className="text-sm opacity-90">~2 min ETA</p>
                  <p className="text-xs opacity-75 mt-2">SMS sent to emergency contacts</p>
                </div>
              </div>

              {/* Alert Details */}
              <div className="p-6 bg-red-50 border-l-4 border-red-500">
                <div className="flex items-start gap-3 mb-3">
                  <div className="size-10 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
                    🚨
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">EMERGENCY ALERT - Atlas</h3>
                    <p className="text-sm text-gray-700 mt-1">Favour Adeyemi needs help!</p>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <MapPin size={16} className="text-gray-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-gray-900">Location: 6.5244°N, 3.3792°E</p>
                      <p className="text-gray-600">(Victoria Island, Lagos)</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Clock size={16} className="text-gray-600 flex-shrink-0" />
                    <p className="text-gray-700">
                      Time: {new Date(currentAlert.date).toLocaleDateString('en-GB', { 
                        day: 'numeric', 
                        month: 'short', 
                        year: 'numeric' 
                      })}, {new Date(currentAlert.date).toLocaleTimeString('en-GB', { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <Phone size={16} className="text-gray-600 flex-shrink-0" />
                    <p className="text-gray-700">Call them: +2348012345678</p>
                  </div>
                </div>
              </div>

              {/* Footer Info */}
              <div className="p-6 bg-gray-50 border-t">
                <div className="text-xs text-gray-600 space-y-1 mb-4">
                  <p className="flex items-center gap-2">
                    <span className="size-1.5 bg-[#008751] rounded-full"></span>
                    Sent via Atlas
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="size-1.5 bg-[#008751] rounded-full"></span>
                    Victoria Island, Lagos · GPS locked
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="size-1.5 bg-[#008751] rounded-full"></span>
                    Emergency contacts notified
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="size-1.5 bg-[#008751] rounded-full"></span>
                    Nearest Atlas responders alerted
                  </p>
                </div>

                <Button 
                  onClick={() => setAlertDialogState("tracking")}
                  className="w-full bg-[#008751] hover:bg-[#006d40] text-white"
                >
                  <Navigation size={18} className="mr-2" />
                  Track Responder →
                </Button>
              </div>
            </div>
          )}

          {alertDialogState === "tracking" && (
            <div className="relative">
              {/* Map View */}
              <div className="relative h-[400px] bg-gray-100">
                {/* Simple map representation */}
                <div className="absolute inset-0 bg-gradient-to-br from-green-100 via-blue-50 to-green-50">
                  {/* Grid lines for map effect */}
                  <div className="absolute inset-0" style={{
                    backgroundImage: 'linear-gradient(rgba(0,135,81,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0,135,81,0.1) 1px, transparent 1px)',
                    backgroundSize: '40px 40px'
                  }}></div>

                  {/* User Location Marker */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
                    <div className="relative">
                      <div className="size-16 bg-red-500 rounded-full flex items-center justify-center text-white shadow-lg animate-pulse">
                        <MapPin size={32} fill="white" />
                      </div>
                      <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap bg-white px-2 py-1 rounded shadow text-xs font-semibold">
                        You
                      </div>
                    </div>
                  </div>

                  {/* Responder Location Marker */}
                  <div className="absolute top-1/4 left-1/4">
                    <div className="relative">
                      <div className="size-14 bg-[#008751] rounded-full flex items-center justify-center text-white shadow-lg">
                        <Shield size={28} />
                      </div>
                      <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap bg-white px-2 py-1 rounded shadow text-xs font-semibold">
                        John O.
                      </div>
                      {/* Distance line */}
                      <svg className="absolute top-7 left-7" width="200" height="150">
                        <line 
                          x1="0" 
                          y1="0" 
                          x2="150" 
                          y2="120" 
                          stroke="#008751" 
                          strokeWidth="2" 
                          strokeDasharray="5,5"
                          opacity="0.5"
                        />
                      </svg>
                    </div>
                  </div>

                  {/* Distance Badge */}
                  <div className="absolute top-1/3 left-1/3 bg-white px-3 py-1.5 rounded-full shadow-md text-xs font-semibold">
                    450m · 2 min
                  </div>
                </div>

                {/* Map Controls */}
                <div className="absolute top-4 right-4 flex flex-col gap-2">
                  <button className="size-10 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50">
                    <span className="text-xl">+</span>
                  </button>
                  <button className="size-10 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50">
                    <span className="text-xl">−</span>
                  </button>
                </div>
              </div>

              {/* Tracking Info */}
              <div className="p-4 bg-white border-t">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="size-12 bg-[#008751] rounded-full flex items-center justify-center text-white font-bold">
                      JO
                    </div>
                    <div>
                      <p className="font-semibold">John O.</p>
                      <p className="text-sm text-gray-600">Security Responder</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-[#008751]">2 min</p>
                    <p className="text-xs text-gray-600">450m away</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1" onClick={() => setAlertDialogState("dispatched")}>
                    Back
                  </Button>
                  <Button className="flex-1 bg-[#008751] hover:bg-[#006d40] text-white">
                    <Phone size={18} className="mr-2" />
                    Call Responder
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}